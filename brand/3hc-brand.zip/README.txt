3HC Advisory Group — logo files
https://www.3hc.cz/brand/

Name: 3HC or 3HC Advisory Group
Legal name: 3HC Advisory Group s.r.o., IČO 06926703, Bubeníčkova 4363/38, 615 00 Brno, Czechia
Websites, mobile apps, Oracle Hyperion (HFM) and IT support, from first idea to running service.
Link: https://www.3hc.cz/ · Contact: info@3hc.cz
Credit line for sites 3HC built: "Web: 3HC", linking to https://www.3hc.cz/

Files (.png = 2x, @4x.png = 4x)
  3hc-lockup-black   ears + 3HC + advisory group, for light backgrounds
  3hc-lockup-white   the same in white, for dark backgrounds
  3hc-ears-black     the ears only, for light backgrounds
  3hc-ears-white     the ears only, for dark backgrounds

Colours: black #000000, white #FFFFFF, muted white rgba(255,255,255,0.6) (text on black)

Typeface: Work Sans 100 ("3HC") and 300 (everything else),
SIL Open Font License (OFL.txt) — https://fonts.google.com/specimen/Work+Sans
